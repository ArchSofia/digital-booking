package com.example.demo.service;

import com.example.demo.repository.CategoriaRepository;

public class CategoriaService implements CategoriaRepository {
}
